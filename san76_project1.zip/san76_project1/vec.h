//
//  vec.h
//  TriangleExample
//
//  Created by Sam Nosenzo on 9/27/17.
//  Copyright © 2017 Sam Nosenzo. All rights reserved.
//

#ifndef vec_h
#define vec_h


#endif /* vec_h */


typedef struct
{
    GLfloat x;
    GLfloat y;
    GLfloat z;
} vec3;

typedef struct
{
    GLfloat x;
    GLfloat y;
    GLfloat z;
    GLfloat w;
} vec4;

typedef vec3 point3;

#define point3(x, y, z) 

